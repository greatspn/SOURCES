#pragma once

#define OGDF_VERSION "2020.02"
