[OGDF](../README.md) » Release Notes

# Release Notes {#relnotes}

Here you find the release notes (usually a summary of noteworthy changes)
for our OGDF releases. If you want information of compatibility-breaking
changes for a specific release, check the [Porting Guide](porting.md).

  * [2019.06 (Catalpa)](relnotes/catalpa.md)
  * [2015.05 (Baobab)](relnotes/baobab.md)
  * [2012.07 (Sakura)](relnotes/sakura.md)
  * [2012.05 (Madrona)](relnotes/madrona.md)
  * [2010.10 (Sassafras)](relnotes/sassafras.md)
  * [2007.11 (Bubinga)](relnotes/bubinga.md)
  * [2007.09 (Jacaranda)](relnotes/jacaranda.md)
